from django.apps import AppConfig


class CarsConfig(AppConfig):
    name = 'cars'
