import { Component, OnInit } from '@angular/core';
import { CarService } from '../car.service';
import { Model } from '../car';

@Component({
  selector: 'app-select-model',
  templateUrl: './select-model.component.html',
  styleUrls: ['./select-model.component.css']
})
export class SelectModelComponent implements OnInit {

  constructor(public car: CarService) { }

  ngOnInit() {
    this.car.loadModels()
  }

  selectModel(model: Model) {
    this.car.selectModel(model)
  }

}
