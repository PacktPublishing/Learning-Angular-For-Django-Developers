import { Injectable } from '@angular/core';
import { Model } from './car';
import { Order } from './order';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from "../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class CarService {

  model: Model = null;
  order: Order = null;

  all_models: Array<Model> = [];
  order_errors: any;

  constructor(private http: HttpClient) {
  }

  loadModels() {
    let url = environment.api_base + '/models/'
    this.http.get(url)
      .subscribe((data: Array<Model>) => {
        this.all_models = data;
      })
  }

  saveOrder() {
    let newOrder = {}
    Object.keys(this.order).forEach((k) => {
      newOrder[k] = this.order[k]
    })
    newOrder['wheels'] = newOrder['wheels'].id
    newOrder['interior'] = newOrder['interior'].id
    newOrder['engine'] = newOrder['engine'].id

    let url = environment.api_base + '/orders/'
    this.http.post(url, newOrder).subscribe(
        data => {
          this.order_errors = {}
          alert("Order saved.")
        },
        (err: HttpErrorResponse) => {
          console.info(err)
          this.order_errors = err.error;
        }
    )
  }

  selectModel(model: Model) {
    this.model = model;
    
    this.order = {
      engine: this.model.engines[0],
      wheels: this.model.wheels[0],
      exterior_color: "#ffff00",
      interior: this.model.interiors[0],
      autopilot: false,

      firstname: 'John',
      lastname: 'Doe',
      phone: '1111',
      email: 'john@doe.com',
      card_number: '1111111111111111',
      card_date: '11/11',
    }
  }
}
