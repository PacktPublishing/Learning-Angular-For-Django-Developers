import { Component, OnInit, Input } from '@angular/core';
import { CarService } from '../car.service';

@Component({
  selector: 'app-server-error',
  templateUrl: './server-error.component.html',
  styleUrls: ['./server-error.component.css']
})
export class ServerErrorComponent implements OnInit {

  @Input() field: string;

  constructor(public car: CarService) { }

  ngOnInit() {
  }

  get errorMessages() {
    if (this.car.order_errors && this.car.order_errors[this.field] !== undefined) {
      return this.car.order_errors[this.field]
    }
    return []
  }

}
