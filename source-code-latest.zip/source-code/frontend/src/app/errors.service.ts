import { Injectable, ErrorHandler } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ErrorsService implements ErrorHandler {

  constructor() { }

  handleError(error: any) {
    console.error(error)

    if (error instanceof HttpErrorResponse){
      alert('Server error: ' + error.message)
    } else {
      alert('Other error: ' + error.message)
    }
    
  }
}
